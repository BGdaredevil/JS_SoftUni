import { html } from "../node_modules/lit-html/lit-html.js";
// import { ifDefined } from "../node_modules/lit-html/directives/if-defined.js";
import { register } from "../Services/dataService.js";

const registerTemplate = (form) => html` <h1>Register</h1>
  <p class="form-info">Already registered? <a href="/login">Login now</a> and have some fun!</p>

  <form action="" @submit=${form.submit}>
    <div>
      <input type="email" placeholder="Email..." name="email" />
    </div>
    <div>
      <input type="password" placeholder="Password" name="password" />
    </div>
    <div>
      <input type="password" placeholder="Re-password" name="repeatPass" />
    </div>
    <div>
      ${form.err !== undefined ? html` <p class="message">${form.err.message}</p> ` : ""}
      <button>Register</button>
    </div>
  </form>`;

export async function registerView(ctx) {
  let form = { submit: onSubmit };
  ctx.render(registerTemplate(form));

  async function onSubmit(e) {
    try {
      e.preventDefault();
      const data = new FormData(e.target);
      const newUser = {
        email: data.get("email").trim(),
        password: data.get("password").trim(),
        repass: data.get("repeatPass").trim(),
      };
      console.log(newUser);
      if (Object.values(newUser).includes("")) {
        form.err = {
          message: "All fields are mandatory",
        };
        ctx.render(registerTemplate(form));
        return;
      }

      if (newUser.repass !== newUser.password) {
        form.err = {
          message: "passwords do not match",
        };
        ctx.render(registerTemplate(form));
        return;
      }

      await register(newUser);
      ctx.page.redirect("/home");
    } catch (err) {
      alert(err);
      console.log(err);
    }
  }
}
